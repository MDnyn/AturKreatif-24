1. Find the flag 
Flag = 4turkr34tif24{username+password} , Hint : Is HTTP secure?

