-Question : Find the flag 
-Hint : 1. How to inspect a file?
		2. How to reveal embedded file?
		3. How to bruteforce password?